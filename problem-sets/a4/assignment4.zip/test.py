import torch

x1 = torch.ones(2, 3, 2)
x2 = 2*torch.ones(2, 3, 2)

print(torch.cat((x1[0], x2[1]), dim=1))